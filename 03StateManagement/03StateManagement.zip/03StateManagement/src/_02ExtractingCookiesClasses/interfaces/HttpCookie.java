package _02ExtractingCookiesClasses.interfaces;

/**
 * Created by IntelliJ IDEA.
 * User: LAPD
 * Date: 28.1.2019 г.
 * Time: 10:43 ч.
 */
public interface HttpCookie {

    String getValue();

    String getKey();
}
