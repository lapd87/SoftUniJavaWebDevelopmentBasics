package _02ExtractingCookiesClasses.interfaces;

public interface InputReader {
    String readLine();
}
