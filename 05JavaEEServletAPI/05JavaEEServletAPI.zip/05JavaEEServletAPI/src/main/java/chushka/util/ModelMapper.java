package chushka.util;

/**
 * Created by IntelliJ IDEA.
 * User: LAPD
 * Date: 31.1.2019 г.
 * Time: 20:05 ч.
 */
public class ModelMapper extends org.modelmapper.ModelMapper {

}