package chushka.io.interfaces;

public interface InputReader {
    String readLine();
}
