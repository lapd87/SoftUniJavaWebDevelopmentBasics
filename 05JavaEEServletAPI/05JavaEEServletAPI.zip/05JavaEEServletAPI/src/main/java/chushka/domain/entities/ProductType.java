package chushka.domain.entities;

/**
 * Created by IntelliJ IDEA.
 * User: LAPD
 * Date: 31.1.2019 г.
 * Time: 19:20 ч.
 */
public enum ProductType {

    Food, Domestic, Health, Cosmetic, Other;
}
