package chushka.domain.models.view;

/**
 * Created by IntelliJ IDEA.
 * User: LAPD
 * Date: 31.1.2019 г.
 * Time: 22:23 ч.
 */
public class ProductAllViewModel {

    private String name;

    public ProductAllViewModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}