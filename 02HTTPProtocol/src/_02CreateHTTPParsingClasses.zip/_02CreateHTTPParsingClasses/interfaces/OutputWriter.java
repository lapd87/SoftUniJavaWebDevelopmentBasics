package _02CreateHTTPParsingClasses.interfaces;

public interface OutputWriter {
    void print(String output);

    void println(String output);
}
