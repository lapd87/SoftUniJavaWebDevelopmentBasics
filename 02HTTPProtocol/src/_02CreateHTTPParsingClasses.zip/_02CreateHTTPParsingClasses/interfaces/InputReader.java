package _02CreateHTTPParsingClasses.interfaces;

public interface InputReader {
    String readLine();
}
