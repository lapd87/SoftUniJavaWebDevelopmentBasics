package exam.repository.interfaces;

import exam.domain.entities.Document;

public interface DocumentRepository extends GenericRepository<Document, String> {

}
