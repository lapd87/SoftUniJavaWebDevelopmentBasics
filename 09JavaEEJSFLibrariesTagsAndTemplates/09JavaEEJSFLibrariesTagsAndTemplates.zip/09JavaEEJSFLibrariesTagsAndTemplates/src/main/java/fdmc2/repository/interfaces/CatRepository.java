package fdmc2.repository.interfaces;

import fdmc2.domain.entities.Cat;

public interface CatRepository extends GenericRepository<Cat, String> {

}
